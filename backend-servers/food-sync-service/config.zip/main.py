from fastapi import FastAPI, Request, HTTPException
from google.cloud import storage, firestore, pubsub_v1
from datetime import datetime, timezone
import time
import json
import base64
import os

app = FastAPI()

storage_client = storage.Client()
db = firestore.Client()
publisher = pubsub_v1.PublisherClient()

# 配置設定 - 使用環境變數或預設值
try:
    from config import PROJECT_ID, NOTIFICATION_TOPIC, INSPECTION_FAILURE_KEYWORDS, NOTIFICATION_SETTINGS
    print(f"📋 使用 config.py 中的配置: {PROJECT_ID}")
except ImportError:
    # 如果 config.py 不存在，使用環境變數或預設值
    PROJECT_ID = os.environ.get("GCP_PROJECT_ID", "micro-service-477116")
    NOTIFICATION_TOPIC = f"projects/{PROJECT_ID}/topics/data-update-notifications"
    INSPECTION_FAILURE_KEYWORDS = ["不合格", "不符合", "違規", "裁罰", "停業", "限期改善"]
    NOTIFICATION_SETTINGS = {
        "high_severity_keywords": ["停業", "裁罰"],
        "medium_severity_keywords": ["限期改善", "違規"],
        "low_severity_keywords": ["不合格", "不符合"]
    }
    print(f"📋 使用預設配置: {PROJECT_ID}")

# ---------------- 工具：發送餐廳稽查不合格通知 ----------------
def send_inspection_failure_notification(restaurant_info: dict):
    """
    發送餐廳稽查不合格通知到 Pub/Sub
    """
    try:
        print(f"🔄 準備發送通知，使用 Topic: {NOTIFICATION_TOPIC}")
        
        restaurant_name = restaurant_info.get("name", "未知餐廳")
        inspection_date = restaurant_info.get("date", "今天")
        status = restaurant_info.get("status", "")
        severity = get_severity_level(status)
        
        # 根據嚴重程度調整標題訊息
        if severity == "high":
            title = f"🚨 緊急通知：'{restaurant_name}' {inspection_date} 稽查嚴重不合格"
        elif severity == "medium":
            title = f"⚠️ 重要通知：'{restaurant_name}' {inspection_date} 稽查需要改善"
        else:
            title = f"📋 通知：'{restaurant_name}' {inspection_date} 稽查不合格"
        
        # 建構通知訊息 - 符合 FCM 服務規範
        notification_data = {
            "type": "inspection_failure",
            "title": "1",  # 必須為 "1" 才會顯示通知
            "message": f"餐廳 '{restaurant_name}' 於 {inspection_date} 的稽查結果為：{status}。請注意食品安全。",
            # targetUserIds 省略表示發送給所有用戶（廣播模式）
            "restaurant_info": {
                "name": restaurant_name,
                "address": restaurant_info.get("address", ""),
                "phone": restaurant_info.get("phone", ""),
                "reg_no": restaurant_info.get("reg_no"),
                "status": status,
                "inspection_date": inspection_date
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "severity": severity
        }
        
        print(f"📝 通知內容: {json.dumps(notification_data, ensure_ascii=False, indent=2)}")
        
        # 轉換為 JSON 字符串
        message_data = json.dumps(notification_data, ensure_ascii=False).encode('utf-8')
        
        # 發布到 Pub/Sub
        print(f"📤 正在發布訊息到 Pub/Sub...")
        future = publisher.publish(NOTIFICATION_TOPIC, message_data)
        message_id = future.result(timeout=30)  # 30秒超時
        
        print(f"✅ 已發送餐廳稽查不合格通知: {restaurant_name} (嚴重程度: {severity}, Message ID: {message_id})")
        return message_id
        
    except Exception as e:
        error_msg = f"❌ 發送通知失敗: {str(e)}"
        print(error_msg)
        print(f"🔧 Debug info - PROJECT_ID: {PROJECT_ID}, TOPIC: {NOTIFICATION_TOPIC}")
        return None

def is_inspection_failed(status: str) -> bool:
    """
    判斷稽查狀態是否為不合格
    """
    if not status:
        return False
    
    status_lower = status.lower()
    return any(keyword in status_lower for keyword in INSPECTION_FAILURE_KEYWORDS)

def get_severity_level(status: str) -> str:
    """
    根據稽查狀態判定嚴重程度
    """
    if not status:
        return "low"
    
    status_lower = status.lower()
    
    for keyword in NOTIFICATION_SETTINGS["high_severity_keywords"]:
        if keyword in status_lower:
            return "high"
    
    for keyword in NOTIFICATION_SETTINGS["medium_severity_keywords"]:
        if keyword in status_lower:
            return "medium"
    
    return "low"

# ---------------- 工具：讀取 GCS JSON（空檔回傳 default） ----------------
def read_gcs_json(bucket_name: str, object_name: str, default):
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(object_name)
    text = blob.download_as_text(encoding="utf-8").strip()
    if text == "":
        return default
    return json.loads(text)

def now_ts():
    now_iso = datetime.now(timezone.utc).isoformat()
    now_ms = int(time.time() * 1000)
    return now_iso, now_ms

# ---------------- 1) HygieneRating：全量重建 ----------------
def process_hygiene_rating(bucket: str, name: str):
    # 空檔就當作 {}
    data = read_gcs_json(bucket, name, default={})
    if not isinstance(data, dict):
        raise ValueError("HygieneRating JSON 應該是 { reg_no: rating }")

    now_iso, now_ms = now_ts()

    new_map = dict(data)  # reg_no -> rating
    batch = db.batch()
    count = 0
    processed = set()

    # 1) 先處理「目前已經有 HygieneRating」的 doc
    docs = db.collection("foodByReg").where("HygieneRating", "!=", None).stream()
    for doc in docs:
        reg_no = doc.id
        doc_ref = doc.reference

        if reg_no in new_map:
            batch.set(
                doc_ref,
                {
                    "HygieneRating": new_map[reg_no],
                    "updatedAtISO": now_iso,
                    "updatedAtMs": now_ms,
                },
                merge=True,
            )
        else:
            # 新 JSON 裡沒有 → 刪掉欄位
            batch.set(
                doc_ref,
                {
                    "HygieneRating": None,
                    "updatedAtISO": now_iso,
                    "updatedAtMs": now_ms,
                },
                merge=True,
            )

        processed.add(reg_no)
        count += 1
        if count >= 400:
            batch.commit()
            batch = db.batch()
            count = 0

    # 2) 這次 JSON 有，但之前沒有 HygieneRating 的
    for reg_no, rating in new_map.items():
        if reg_no in processed:
            continue
        doc_ref = db.collection("foodByReg").document(reg_no)
        batch.set(
            doc_ref,
            {
                "HygieneRating": rating,
                "updatedAtISO": now_iso,
                "updatedAtMs": now_ms,
            },
            merge=True,
        )
        count += 1
        if count >= 400:
            batch.commit()
            batch = db.batch()
            count = 0

    if count > 0:
        batch.commit()

# ---------------- 2) InspectionResults：增量更新 ----------------
def process_inspection_results(bucket: str, name: str):
    # 空檔就當作沒有任何更新 []
    records = read_gcs_json(bucket, name, default=[])
    if not isinstance(records, list):
        raise ValueError("InspectionResults JSON 應該是一個陣列")

    now_iso, now_ms = now_ts()
    batch = db.batch()
    count = 0

    for r in records:
        reg_no = r.get("登錄字號")
        if not reg_no:
            continue

        status = r.get("狀態")
        inspection_obj = {
            "status": status,
            "date": r.get("日期"),
            "name": r.get("名稱"),
            "address": r.get("地址"),
            "phone": r.get("電話"),
        }

        # 檢查是否為不合格狀態，如果是則發送通知
        if is_inspection_failed(status):
            restaurant_info = {
                "reg_no": reg_no,
                "name": r.get("名稱"),
                "address": r.get("地址"),
                "phone": r.get("電話"),
                "status": status,
                "date": r.get("日期")
            }
            send_inspection_failure_notification(restaurant_info)

        doc_ref = db.collection("foodByReg").document(reg_no)
        # 只更新這次 JSON 有出現的，其它完全不動
        batch.set(
            doc_ref,
            {
                "InspectionResults": inspection_obj,
                "updatedAtISO": now_iso,
                "updatedAtMs": now_ms,
            },
            merge=True,
        )

        count += 1
        if count >= 400:
            batch.commit()
            batch = db.batch()
            count = 0

    if count > 0:
        batch.commit()

# ---------------- 3) nightMarketName：全量重建 ----------------
def process_night_markets(bucket: str, name: str):
    # 空檔就當作 {}
    raw = read_gcs_json(bucket, name, default={})
    if not isinstance(raw, dict):
        raise ValueError("nightMarket JSON 應該是 { marketName: [stalls...] }")

    now_iso, now_ms = now_ts()

    # 這次 JSON 攤平成 reg_no -> (market_name, info)
    new_map = {}
    for market_name, stalls in raw.items():
        if not isinstance(stalls, list):
            continue

        for s in stalls:
            reg_no = s.get("食品業者登錄字號")
            if not reg_no:
                continue

            info = {
                "year": s.get("年度"),
                "stallName": s.get("攤位名稱"),
                "evaluationResult": s.get("評核結果"),
            }
            new_map[reg_no] = (market_name, info)

    batch = db.batch()
    count = 0
    processed = set()

    # 1) 先處理「目前已經有 nightMarketName」的 doc
    docs = db.collection("foodByReg").where("nightMarketName", "!=", None).stream()
    for doc in docs:
        reg_no = doc.id
        doc_ref = doc.reference

        if reg_no in new_map:
            market_name, info = new_map[reg_no]
            batch.set(
                doc_ref,
                {
                    "nightMarketName": market_name,
                    "nightMarketInfo": info,
                    "updatedAtISO": now_iso,
                    "updatedAtMs": now_ms,
                },
                merge=True,
            )
        else:
            # 新 JSON 裡沒有 → 刪掉欄位
            batch.update(
                doc_ref,
                {
                    "nightMarketName": None,
                    "nightMarketInfo": firestore.DELETE_FIELD,
                    "updatedAtISO": now_iso,
                    "updatedAtMs": now_ms,
                },
            )


        processed.add(reg_no)
        count += 1
        if count >= 400:
            batch.commit()
            batch = db.batch()
            count = 0

    # 2) 這次 JSON 有，但之前沒有 nightMarketName 的
    for reg_no, (market_name, info) in new_map.items():
        if reg_no in processed:
            continue

        doc_ref = db.collection("foodByReg").document(reg_no)
        batch.set(
            doc_ref,
            {
                "nightMarketName": market_name,
                "nightMarketInfo": info,
                "updatedAtISO": now_iso,
                "updatedAtMs": now_ms,
            },
            merge=True,
        )
        count += 1
        if count >= 400:
            batch.commit()
            batch = db.batch()
            count = 0

    if count > 0:
        batch.commit()

# ---------------- Cloud Run 入口：接 Eventarc ----------------
@app.post("/")
async def handle_event(request: Request):
    body = await request.json()
    print("RAW_EVENT:", body)

    bucket = None
    name = None

    # 情況 0：最外層就有 bucket / name
    if isinstance(body, dict) and "bucket" in body and "name" in body:
        bucket = body["bucket"]
        name = body["name"]

    # 情況 1：CloudEvent 格式，data.bucket / data.name
    elif "data" in body and isinstance(body["data"], dict) and "bucket" in body["data"]:
        bucket = body["data"]["bucket"]
        name = body["data"]["name"]

    # 情況 2：Pub/Sub push，body.message.data(Base64)
    elif "message" in body:
        msg = body["message"]
        data_b64 = msg.get("data")
        if data_b64:
            decoded = base64.b64decode(data_b64).decode("utf-8")
            inner = json.loads(decoded)
            if "bucket" in inner and "name" in inner:
                bucket = inner["bucket"]
                name = inner["name"]
            elif "data" in inner and isinstance(inner["data"], dict):
                bucket = inner["data"]["bucket"]
                name = inner["data"]["name"]

    if not bucket or not name:
        raise HTTPException(
            status_code=400,
            detail="Unknown event format or missing bucket/name"
        )

    if name.startswith("hygiene/"):
        process_hygiene_rating(bucket, name)
    elif name.startswith("inspection/"):
        process_inspection_results(bucket, name)
    elif name.startswith("night_market/"):
        process_night_markets(bucket, name)
    else:
        return {"status": "ignored", "bucket": bucket, "name": name}

    return {"status": "ok", "bucket": bucket, "name": name}

# ---------------- 測試端點：手動發送通知 ----------------
@app.post("/test-notification")
async def test_notification(request: Request):
    """
    測試端點：手動發送餐廳稽查不合格通知
    """
    try:
        body = await request.json()
        
        # 預設測試資料
        test_restaurant = {
            "reg_no": body.get("reg_no", "TEST123456"),
            "name": body.get("name", "測試餐廳"),
            "address": body.get("address", "台北市信義區測試路123號"),
            "phone": body.get("phone", "02-1234-5678"),
            "status": body.get("status", "不合格"),
            "date": body.get("date", datetime.now().strftime("%Y-%m-%d"))
        }
        
        message_id = send_inspection_failure_notification(test_restaurant)
        
        if message_id:
            return {
                "status": "success",
                "message": "測試通知已發送",
                "message_id": message_id,
                "restaurant_info": test_restaurant
            }
        else:
            return {
                "status": "error",
                "message": "發送通知失敗"
            }
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"測試通知失敗: {str(e)}")

@app.get("/health")
async def health_check():
    """健康檢查端點"""
    return {"status": "healthy", "service": "food-sync-service"}

@app.get("/debug")
async def debug_info():
    """調試資訊端點"""
    return {
        "project_id": PROJECT_ID,
        "notification_topic": NOTIFICATION_TOPIC,
        "failure_keywords": INSPECTION_FAILURE_KEYWORDS,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

@app.get("/debug-config")
async def debug_config():
    """調試配置端點"""
    return {
        "project_id": PROJECT_ID,
        "notification_topic": NOTIFICATION_TOPIC,
        "inspection_failure_keywords": INSPECTION_FAILURE_KEYWORDS,
        "notification_settings": NOTIFICATION_SETTINGS
    }
